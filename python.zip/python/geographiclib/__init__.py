"""geographiclib: geodesic routines from GeographicLib"""

__version_info__ = (1, 52, 0)
"""GeographicLib version as a tuple"""

__version__ = "1.52"
"""GeographicLib version as a string"""
